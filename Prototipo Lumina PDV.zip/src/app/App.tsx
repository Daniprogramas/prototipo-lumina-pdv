import { useState, useEffect, useRef, useCallback } from "react";
import {
  Monitor, ShoppingCart, Package, Gamepad2, Settings, HelpCircle,
  Search, Plus, Minus, Trash2, Check, Sun, Moon, Contrast,
  ArrowLeft, X, User, Lock, LogIn, Receipt,
  AlertCircle, Printer, Eye, UserCircle, Users, Volume2, VolumeX,
  Keyboard, ShieldCheck, RotateCcw, LogOut, UserPlus, RefreshCw,
  Edit2, FileText, TrendingUp, Archive, Scan,
} from "lucide-react";

// ── Helpers ────────────────────────────────────────────────────────────────────

const IMG = (id: string, w = 320, h = 320) =>
  `https://images.unsplash.com/${id}?w=${w}&h=${h}&fit=crop&auto=format&q=80`;

const fmt = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const genSaleNumber = () =>
  `#${String(Math.floor(Math.random() * 90000) + 10000)}`;

// ── Types ──────────────────────────────────────────────────────────────────────

type Screen =
  | "login"
  | "manager-dashboard"
  | "user-management"
  | "operator-registration"
  | "registration-success"
  | "operator-menu"
  | "register"
  | "review"
  | "confirmation";

type Category = "Todos" | "Serviços" | "Jogos e Créditos" | "Informática" | "Conveniência";
type PaymentMethod = "Dinheiro" | "Pix" | "Cartão de Débito" | "Cartão de Crédito" | "";
type UserProfile = "Operador de Caixa" | "Gerente de Loja";

interface Product {
  id: number;
  name: string;
  price: number;
  category: Exclude<Category, "Todos">;
  barcode: string;
  photo: string;
}

interface CartItem {
  product: Product;
  quantity: number;
}

interface Operator {
  id: number;
  fullName: string;
  username: string;
  profile: UserProfile;
  avatar: string;
}

interface A11ySettings {
  theme: "light" | "dark";
  highContrast: boolean;
  fontSize: number;
  screenReader: boolean;
}

type A11yProps = {
  s: A11ySettings;
  onToggleTheme: () => void; onFontUp: () => void; onFontDown: () => void;
  onFontReset: () => void;   onToggleHC: () => void; onToggleSR: () => void;
  onShowKbdGuide: () => void;
};

// ── Credentials ────────────────────────────────────────────────────────────────

const CREDENTIALS: Record<string, { role: "manager" | "operator" }> = {
  "sara.gerente:LuminaGestor2026": { role: "manager" },
  "operador.lan:LuminaLan2026":    { role: "operator" },
};

// ── Products ───────────────────────────────────────────────────────────────────

const PRODUCTS: Product[] = [
  { id: 1,  name: "30 Min. de Computador",    price: 4.00,  category: "Serviços",         barcode: "7891234560010", photo: IMG("photo-1573235781593-0094b20e59d2") },
  { id: 2,  name: "1 Hora de Computador",     price: 8.00,  category: "Serviços",         barcode: "7891234560027", photo: IMG("photo-1573235781593-0094b20e59d2") },
  { id: 3,  name: "Impressão P&B",            price: 0.50,  category: "Serviços",         barcode: "7891234560034", photo: IMG("photo-1503694978374-8a2fa686963a") },
  { id: 4,  name: "Impressão Colorida",       price: 2.00,  category: "Serviços",         barcode: "7891234560041", photo: IMG("photo-1706895040634-62055892cbbb") },
  { id: 5,  name: "Digitalização Doc.",       price: 1.50,  category: "Serviços",         barcode: "7891234560058", photo: IMG("photo-1706895040634-62055892cbbb") },
  { id: 6,  name: "Encadernação Simples",     price: 5.00,  category: "Serviços",         barcode: "7891234560065", photo: IMG("photo-1503694978374-8a2fa686963a") },
  { id: 7,  name: "Free Fire 100 Diamantes",  price: 4.49,  category: "Jogos e Créditos", barcode: "7892345670010", photo: IMG("photo-1779896412430-b9ea6a9e742d") },
  { id: 8,  name: "Free Fire 310 Diamantes",  price: 13.99, category: "Jogos e Créditos", barcode: "7892345670027", photo: IMG("photo-1779896412430-b9ea6a9e742d") },
  { id: 9,  name: "Roblox 400 Robux",         price: 25.00, category: "Jogos e Créditos", barcode: "7892345670034", photo: IMG("photo-1779896412317-5768a1911afb") },
  { id: 10, name: "Roblox 800 Robux",         price: 50.00, category: "Jogos e Créditos", barcode: "7892345670041", photo: IMG("photo-1779896412317-5768a1911afb") },
  { id: 11, name: "Crédito League of Legends",price: 20.00, category: "Jogos e Créditos", barcode: "7892345670058", photo: IMG("photo-1779896412430-b9ea6a9e742d") },
  { id: 12, name: "Crédito Steam Wallet",     price: 30.00, category: "Jogos e Créditos", barcode: "7892345670065", photo: IMG("photo-1779896412317-5768a1911afb") },
  { id: 13, name: "Fone de Ouvido Simples",   price: 25.00, category: "Informática",      barcode: "7893456780010", photo: IMG("photo-1560419015-7c427e8ae5ba") },
  { id: 14, name: "Headset Gamer Básico",     price: 89.00, category: "Informática",      barcode: "7893456780027", photo: IMG("photo-1610041321327-b794c052db27") },
  { id: 15, name: "Caixa de Som USB",         price: 45.00, category: "Informática",      barcode: "7893456780034", photo: IMG("photo-1608043152269-423dbba4e7e1") },
  { id: 16, name: "Caixa de Som Bluetooth",   price: 79.00, category: "Informática",      barcode: "7893456780041", photo: IMG("photo-1589256469067-ea99122bbdc4") },
  { id: 17, name: "Carregador USB Universal", price: 30.00, category: "Informática",      barcode: "7893456780058", photo: IMG("photo-1677145503731-87bfe49e5c67") },
  { id: 18, name: "Cabo USB-C",               price: 15.00, category: "Informática",      barcode: "7893456780065", photo: IMG("photo-1677145503755-5a8c581671fe") },
  { id: 19, name: "Cabo Micro USB",           price: 12.00, category: "Informática",      barcode: "7893456780072", photo: IMG("photo-1677145503755-5a8c581671fe") },
  { id: 20, name: "Cabo Lightning",           price: 25.00, category: "Informática",      barcode: "7893456780089", photo: IMG("photo-1566793474285-2decf0fc182a") },
  { id: 21, name: "Mouse Gamer Básico",       price: 45.00, category: "Informática",      barcode: "7893456780096", photo: IMG("photo-1698422454409-eb41174f1355") },
  { id: 22, name: "Mouse Pad Gamer",          price: 20.00, category: "Informática",      barcode: "7893456780102", photo: IMG("photo-1698422454409-eb41174f1355") },
  { id: 23, name: "Teclado USB Simples",      price: 50.00, category: "Informática",      barcode: "7893456780119", photo: IMG("photo-1698422454438-da3c03db4d96") },
  { id: 24, name: "Pen Drive 32GB",           price: 35.00, category: "Informática",      barcode: "7893456780126", photo: IMG("photo-1551818014-7c8ace9c1b5c") },
  { id: 25, name: "Pen Drive 64GB",           price: 55.00, category: "Informática",      barcode: "7893456780133", photo: IMG("photo-1477949331575-2763034b5fb5") },
  { id: 26, name: "Água Mineral",             price: 3.00,  category: "Conveniência",     barcode: "7894567890010", photo: IMG("photo-1616118132534-381148898bb4") },
  { id: 27, name: "Refrigerante Lata",        price: 5.00,  category: "Conveniência",     barcode: "7894567890027", photo: IMG("photo-1592892111425-15e04305f961") },
  { id: 28, name: "Salgadinho",               price: 4.00,  category: "Conveniência",     barcode: "7894567890034", photo: IMG("photo-1613919113640-25732ec5e61f") },
  { id: 29, name: "Chocolate",                price: 3.50,  category: "Conveniência",     barcode: "7894567890041", photo: IMG("photo-1610450949065-1f2841536c88") },
];

const INITIAL_OPERATORS: Operator[] = [
  { id: 1, fullName: "Francisco de Assis", username: "francisco.assis", profile: "Gerente de Loja",   avatar: IMG("photo-1639747279286-c07eecb47a0b", 200, 200) },
  { id: 2, fullName: "Maria Aparecida",    username: "maria.aparecida", profile: "Operador de Caixa", avatar: IMG("photo-1582896911227-c966f6e7fb93", 200, 200) },
  { id: 3, fullName: "Carlos Eduardo",     username: "carlos.edu",      profile: "Operador de Caixa", avatar: IMG("photo-1607746882042-944635dfe10e", 200, 200) },
];

// ── Keyboard Guide Modal ───────────────────────────────────────────────────────

function KeyboardGuide({ onClose }: { onClose: () => void }) {
  const shortcuts = [
    { key: "Alt + 1", desc: "Menu Principal" },
    { key: "Alt + 2", desc: "Nova Venda" },
    { key: "Alt + 3", desc: "Limpar / Nova Venda" },
    { key: "Alt + 4", desc: "Confirmar / Finalizar Venda" },
    { key: "Alt + 0", desc: "Guia de Atalhos (esta janela)" },
    { key: "Esc",     desc: "Fechar modal / Cancelar" },
    { key: "Tab",     desc: "Próximo elemento focável" },
    { key: "Enter",   desc: "Ativar botão focado" },
  ];
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog" aria-modal="true" aria-labelledby="kbd-title">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} aria-hidden="true" />
      <div className="relative bg-card border border-border rounded-2xl shadow-2xl w-full max-w-sm">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <h2 id="kbd-title" className="font-bold text-foreground flex items-center gap-2 text-sm">
            <Keyboard size={16} className="text-primary" aria-hidden="true" />
            Guia de Atalhos de Teclado
          </h2>
          <button onClick={onClose} aria-label="Fechar" autoFocus
            className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring">
            <X size={16} aria-hidden="true" />
          </button>
        </div>
        <div className="p-5">
          <table className="w-full text-sm">
            <thead>
              <tr>
                <th className="text-left text-xs font-semibold text-muted-foreground pb-2">Atalho</th>
                <th className="text-left text-xs font-semibold text-muted-foreground pb-2">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {shortcuts.map(({ key, desc }) => (
                <tr key={key}>
                  <td className="py-2 pr-4"><kbd className="pdv-kbd font-mono whitespace-nowrap">{key}</kbd></td>
                  <td className="py-2 text-foreground">{desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="text-xs text-muted-foreground mt-4">Pressione <kbd className="pdv-kbd">Esc</kbd> para fechar.</p>
        </div>
      </div>
    </div>
  );
}

// ── Accessibility Toolbar ──────────────────────────────────────────────────────

function A11yBar({ s, onToggleTheme, onFontUp, onFontDown, onFontReset, onToggleHC, onToggleSR, onShowKbdGuide }: A11yProps) {
  return (
    <div role="toolbar" aria-label="Controles de acessibilidade"
      className="flex items-center gap-1.5 px-4 py-2 border-b border-border bg-card shrink-0 flex-wrap">
      <span className="text-xs font-semibold text-muted-foreground mr-1 hidden md:block select-none">Acessibilidade</span>
      <button onClick={onToggleTheme}
        aria-label={s.theme === "light" ? "Ativar modo escuro" : "Ativar modo claro"}
        className="a11y-btn gap-1.5">
        {s.theme === "light" ? <Moon size={13} aria-hidden="true" /> : <Sun size={13} aria-hidden="true" />}
        <span className="hidden lg:inline text-xs">{s.theme === "light" ? "Escuro" : "Claro"}</span>
      </button>
      <button onClick={onToggleHC} aria-pressed={s.highContrast}
        aria-label={s.highContrast ? "Desativar alto contraste" : "Ativar alto contraste"}
        className={`a11y-btn gap-1.5 ${s.highContrast ? "a11y-btn-active" : ""}`}>
        <Contrast size={13} aria-hidden="true" />
        <span className="hidden lg:inline text-xs">Contraste</span>
      </button>
      <div className="flex items-center gap-0.5 border-l border-border pl-2 ml-0.5" role="group" aria-label="Tamanho da fonte">
        <button onClick={onFontDown} aria-label="Diminuir fonte" title="A-" disabled={s.fontSize <= 14}
          className="a11y-btn font-bold text-[10px] w-7 justify-center disabled:opacity-30">A-</button>
        <button onClick={onFontReset} aria-label="Restaurar fonte" title="Restaurar"
          className="a11y-btn w-6 justify-center"><RotateCcw size={11} aria-hidden="true" /></button>
        <button onClick={onFontUp} aria-label="Aumentar fonte" title="A+" disabled={s.fontSize >= 26}
          className="a11y-btn font-bold text-[10px] w-7 justify-center disabled:opacity-30">A+</button>
      </div>
      <button onClick={onToggleSR} aria-pressed={s.screenReader}
        aria-label={s.screenReader ? "Desativar leitor de tela" : "Ativar leitor de tela"}
        className={`a11y-btn gap-1.5 border-l border-border ml-0.5 pl-2 ${s.screenReader ? "a11y-btn-active" : ""}`}>
        {s.screenReader ? <Volume2 size={13} aria-hidden="true" /> : <VolumeX size={13} aria-hidden="true" />}
        <span className="hidden lg:inline text-xs">Leitor: {s.screenReader ? "Ativo" : "Inativo"}</span>
      </button>
      <button onClick={onShowKbdGuide} aria-label="Guia de teclado (Alt+0)"
        className="a11y-btn gap-1.5">
        <Keyboard size={13} aria-hidden="true" />
        <span className="hidden lg:inline text-xs">Teclado</span>
      </button>
      <span className="text-xs text-muted-foreground ml-auto hidden xl:block select-none tabular-nums">{s.fontSize}px</span>
    </div>
  );
}

function SRBanner({ active }: { active: boolean }) {
  if (!active) return null;
  return (
    <div className="bg-primary/10 border-b border-primary/20 px-4 py-1.5 flex items-center gap-2 shrink-0" role="status" aria-live="polite">
      <Volume2 size={13} className="text-primary shrink-0" aria-hidden="true" />
      <span className="text-xs text-primary font-medium">Leitor de tela ativo — navegação por teclado e ARIA labels habilitados</span>
    </div>
  );
}

// ── App Header ─────────────────────────────────────────────────────────────────

function AppHeader({ title, subtitle, onBack, backLabel, badge, trailing }: {
  title: string; subtitle?: string; onBack?: () => void; backLabel?: string;
  badge?: string; trailing?: React.ReactNode;
}) {
  return (
    <header className="bg-primary text-primary-foreground px-4 py-3 flex items-center gap-3 shrink-0" role="banner">
      {onBack && (
        <button onClick={onBack} aria-label={backLabel ?? "Voltar"}
          className="p-1.5 rounded-lg hover:bg-primary-foreground/15 focus:outline-none focus:ring-2 focus:ring-primary-foreground/60 transition-colors shrink-0">
          <ArrowLeft size={20} aria-hidden="true" />
        </button>
      )}
      <Monitor size={18} className="shrink-0 opacity-80" aria-hidden="true" />
      <div className="flex-1 min-w-0">
        <span className="font-bold text-base block truncate">{title}</span>
        {subtitle && <span className="text-xs opacity-70 block truncate">{subtitle}</span>}
      </div>
      {badge && <span className="bg-primary-foreground text-primary text-xs font-bold px-2 py-0.5 rounded-full shrink-0" aria-live="polite">{badge}</span>}
      {trailing}
    </header>
  );
}

// ── Screen: Login ──────────────────────────────────────────────────────────────

function LoginScreen({ onLogin, ...a }: { onLogin: (role: "manager" | "operator") => void } & A11yProps) {
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [error, setError] = useState("");
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const match = CREDENTIALS[`${user.trim()}:${pass}`];
    if (match) onLogin(match.role);
    else setError("Usuário ou senha incorretos. Verifique as credenciais.");
  };
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <A11yBar {...a} /><SRBanner active={a.s.screenReader} />
      <main className="flex-1 flex items-center justify-center p-6" role="main">
        <div className="w-full max-w-xs">
          <div className="text-center mb-10">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary mb-4 shadow-lg" aria-hidden="true">
              <Monitor size={28} className="text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-foreground tracking-tight">Lumina PDV</h1>
            <p className="text-muted-foreground text-sm mt-1">Sistema de Ponto de Venda</p>
          </div>
          <form onSubmit={handleSubmit} className="space-y-5" aria-label="Formulário de acesso" noValidate>
            <div>
              <label htmlFor="login-user" className="block text-sm font-semibold text-foreground mb-1.5">Usuário</label>
              <div className="relative">
                <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" aria-hidden="true" />
                <input id="login-user" type="text" value={user}
                  onChange={(e) => { setUser(e.target.value); setError(""); }}
                  placeholder="Digite seu usuário" autoComplete="username" autoFocus
                  className="pdv-input pl-9" aria-required="true"
                  aria-describedby={error ? "login-error" : undefined} />
              </div>
            </div>
            <div>
              <label htmlFor="login-pass" className="block text-sm font-semibold text-foreground mb-1.5">Senha</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" aria-hidden="true" />
                <input id="login-pass" type="password" value={pass}
                  onChange={(e) => { setPass(e.target.value); setError(""); }}
                  placeholder="Digite sua senha" autoComplete="current-password"
                  className="pdv-input pl-9" aria-required="true"
                  aria-describedby={error ? "login-error" : undefined} />
              </div>
            </div>
            {error && (
              <div id="login-error" role="alert" className="flex items-start gap-2 bg-destructive/10 border border-destructive/30 rounded-lg px-3 py-2.5">
                <AlertCircle size={15} className="text-destructive mt-0.5 shrink-0" aria-hidden="true" />
                <p className="text-xs text-destructive leading-snug">{error}</p>
              </div>
            )}
            <button type="submit" className="pdv-btn-primary w-full py-3">
              <LogIn size={16} className="mr-2" aria-hidden="true" />Entrar
            </button>
          </form>
          <div className="mt-7 rounded-xl border border-border bg-muted/40 p-4 space-y-1.5">
            <p className="text-xs font-semibold text-muted-foreground mb-2">Credenciais de demonstração:</p>
            <p className="text-xs text-muted-foreground"><span className="font-medium text-foreground">Gestor:</span> sara.gerente / LuminaGestor2026</p>
            <p className="text-xs text-muted-foreground"><span className="font-medium text-foreground">Operador:</span> operador.lan / LuminaLan2026</p>
          </div>
        </div>
      </main>
    </div>
  );
}

// ── Screen: Manager Dashboard ──────────────────────────────────────────────────

function ManagerDashboard({ onGoToUsers, onLogout, ...a }: { onGoToUsers: () => void; onLogout: () => void } & A11yProps) {
  const now = new Date();
  const cards = [
    { icon: Users,        label: "Gestão de Usuários",    desc: "Cadastrar e gerenciar operadores", active: true,  onClick: onGoToUsers },
    { icon: ShoppingCart, label: "Gestão de Vendas",      desc: "Histórico de transações",          active: false },
    { icon: Package,      label: "Produtos",              desc: "Catálogo e preços",                active: false },
    { icon: TrendingUp,   label: "Movimentação",          desc: "Fluxo de caixa",                   active: false },
    { icon: FileText,     label: "Relatório",             desc: "Relatórios gerenciais",            active: false },
    { icon: Archive,      label: "Indicador de Estoque",  desc: "Controle de inventário",           active: false },
  ];
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <A11yBar {...a} /><SRBanner active={a.s.screenReader} />
      <AppHeader title="Lumina PDV" subtitle="GERENTE SARA — UNIDADE CENTRAL"
        trailing={
          <button onClick={onLogout}
            className="text-xs opacity-75 hover:opacity-100 flex items-center gap-1.5 focus:outline-none focus:ring-2 focus:ring-primary-foreground/60 rounded px-1"
            aria-label="Sair">
            <LogOut size={14} aria-hidden="true" /><span className="hidden sm:inline">Sair</span>
          </button>
        }
      />
      <main className="flex-1 p-6 max-w-3xl mx-auto w-full" role="main">
        <div className="mb-7">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary rounded-full px-3 py-1 text-xs font-semibold mb-3">
            <ShieldCheck size={13} aria-hidden="true" />Perfil: Gerente de Loja
          </div>
          <h1 className="text-xl font-bold text-foreground">Painel Administrativo</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {now.toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "long", year: "numeric" })}
          </p>
        </div>
        <nav aria-label="Menu administrativo">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {cards.map((card) => (
              <button key={card.label}
                onClick={card.active ? card.onClick : undefined}
                disabled={!card.active}
                aria-label={card.active ? card.label : `${card.label} — Indisponível no MVP`}
                className={`
                  text-left rounded-xl p-5 transition-all focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2
                  ${card.active
                    ? "bg-primary text-primary-foreground border-2 border-primary shadow-md hover:opacity-95 active:scale-[0.98] cursor-pointer"
                    : "bg-card border-2 border-dashed border-border opacity-40 cursor-not-allowed"
                  }
                `}
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${card.active ? "bg-primary-foreground/20" : "bg-muted"}`} aria-hidden="true">
                  <card.icon size={20} className={card.active ? "text-primary-foreground" : "text-muted-foreground"} />
                </div>
                <span className={`font-semibold text-sm block ${card.active ? "text-primary-foreground" : "text-muted-foreground"}`}>{card.label}</span>
                <span className={`text-xs mt-0.5 block leading-tight ${card.active ? "text-primary-foreground/65" : "text-muted-foreground/70"}`}>{card.desc}</span>
                {!card.active && (
                  <span className="mt-2 inline-block text-[10px] font-semibold bg-muted/60 text-muted-foreground px-2 py-0.5 rounded uppercase tracking-wide">
                    Indisponível no MVP
                  </span>
                )}
              </button>
            ))}
          </div>
        </nav>
      </main>
    </div>
  );
}

// ── Screen: User Management ────────────────────────────────────────────────────

function UserManagement({ operators, onAdd, onDelete, onBack, ...a }: {
  operators: Operator[]; onAdd: () => void; onDelete: (id: number) => void; onBack: () => void;
} & A11yProps) {
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  const profileBadge: Record<UserProfile, string> = {
    "Gerente de Loja":   "bg-primary/10 text-primary border border-primary/25",
    "Operador de Caixa": "bg-green-100 text-green-700 border border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800",
  };

  const getInitials = (name: string) =>
    name.split(" ").slice(0, 2).map((n) => n[0]).join("").toUpperCase();

  const handleDelete = (id: number) => {
    if (deleteConfirm === id) { onDelete(id); setDeleteConfirm(null); }
    else setDeleteConfirm(id);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <A11yBar {...a} /><SRBanner active={a.s.screenReader} />
      <AppHeader title="Gestão de Usuários" subtitle="Operadores do sistema"
        onBack={onBack} backLabel="Voltar ao painel"
        badge={`${operators.length} ${operators.length === 1 ? "operador" : "operadores"}`}
      />
      <main className="flex-1 overflow-y-auto scrollbar-thin" role="main">
        {/* Sticky action bar */}
        <div className="sticky top-0 z-10 bg-card border-b border-border px-6 py-4 flex items-center justify-between">
          <h2 className="font-semibold text-foreground text-sm flex items-center gap-2">
            <Users size={16} className="text-primary" aria-hidden="true" />
            Operadores Ativos
          </h2>
          <button onClick={onAdd} className="pdv-btn-primary py-2.5 px-5" aria-label="Adicionar novo operador">
            <UserPlus size={16} className="mr-2" aria-hidden="true" />
            + Adicionar Novo Operador
          </button>
        </div>

        <div className="p-6 max-w-3xl mx-auto space-y-3" role="list" aria-label="Lista de operadores">
          {operators.length === 0 ? (
            <div className="text-center text-muted-foreground py-16">
              <Users size={40} className="mx-auto mb-3 opacity-25" aria-hidden="true" />
              <p className="font-medium">Nenhum operador cadastrado</p>
              <p className="text-sm mt-1 opacity-70">Clique em "+ Adicionar Novo Operador" para começar.</p>
            </div>
          ) : operators.map((op) => (
            <div key={op.id}
              className="bg-card border border-border rounded-xl p-4 flex items-center gap-5 hover:border-primary/20 transition-colors"
              role="listitem" aria-label={`Operador: ${op.fullName}`}>

              {/* Avatar — large, square, thick border */}
              <div className="shrink-0">
                <div className="w-16 h-16 rounded-xl overflow-hidden border-[3px] border-foreground/20 bg-muted" aria-hidden="true">
                  {op.avatar ? (
                    <img src={op.avatar} alt={`Foto de ${op.fullName}`}
                      className="w-full h-full object-cover object-top"
                      onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-primary/10 text-primary font-bold text-lg">
                      {getInitials(op.fullName)}
                    </div>
                  )}
                </div>
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <p className="font-bold text-foreground text-base uppercase tracking-wide truncate">{op.fullName}</p>
                <p className="text-sm text-muted-foreground font-mono mt-0.5">@{op.username}</p>
                <span className={`mt-1.5 inline-block text-xs font-semibold px-2.5 py-0.5 rounded-full ${profileBadge[op.profile]}`}>
                  {op.profile}
                </span>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  aria-label={`Editar ${op.fullName}`}
                  className="inline-flex items-center gap-1.5 rounded-lg border-2 border-primary bg-primary/5 text-primary font-semibold px-3.5 py-2 text-sm hover:bg-primary hover:text-primary-foreground transition-colors focus:outline-none focus:ring-2 focus:ring-ring">
                  <Edit2 size={14} aria-hidden="true" />
                  <span className="hidden sm:inline">Editar</span>
                </button>
                <button
                  onClick={() => handleDelete(op.id)}
                  aria-label={deleteConfirm === op.id ? `Confirmar exclusão de ${op.fullName}` : `Excluir ${op.fullName}`}
                  className={`inline-flex items-center gap-1.5 rounded-lg border-2 font-semibold px-3.5 py-2 text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-destructive
                    ${deleteConfirm === op.id
                      ? "border-destructive bg-destructive text-white"
                      : "border-destructive/60 bg-destructive/5 text-destructive hover:bg-destructive hover:text-white"}`}>
                  <Trash2 size={14} aria-hidden="true" />
                  <span className="hidden sm:inline">{deleteConfirm === op.id ? "Confirmar?" : "Excluir"}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

// ── Screen: Operator Registration ─────────────────────────────────────────────

function OperatorRegistration({ onSave, onBack, ...a }: {
  onSave: (op: Omit<Operator, "id" | "avatar">) => void; onBack: () => void;
} & A11yProps) {
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [profile, setProfile]   = useState<UserProfile>("Operador de Caixa");
  const [errors, setErrors]     = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!fullName.trim()) e.fullName = "Nome completo é obrigatório.";
    if (!username.trim()) e.username = "Nome de usuário é obrigatório.";
    else if (!/^[a-z0-9_.]+$/.test(username)) e.username = "Use apenas letras minúsculas, números e pontos.";
    if (!password.trim()) e.password = "Senha é obrigatória.";
    else if (password.length < 6) e.password = "Senha deve ter pelo menos 6 caracteres.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) onSave({ fullName: fullName.trim(), username: username.trim(), profile });
  };

  const Field = ({ id, label, value, onChange, type = "text", placeholder, error, hint, mono = false }: {
    id: string; label: string; value: string; onChange: (v: string) => void;
    type?: string; placeholder: string; error?: string; hint?: string; mono?: boolean;
  }) => (
    <div>
      <label htmlFor={id} className="block text-sm font-semibold text-foreground mb-1.5">
        {label} <span className="text-destructive" aria-hidden="true">*</span>
      </label>
      <input id={id} type={type} value={value}
        onChange={(e) => { onChange(e.target.value); setErrors(p => ({ ...p, [id.replace("reg-", "")]: "" })); }}
        placeholder={placeholder} autoComplete={type === "password" ? "new-password" : "off"}
        className={`pdv-input ${mono ? "font-mono" : ""} ${error ? "border-destructive" : ""}`}
        aria-required="true" aria-invalid={!!error}
        aria-describedby={error ? `err-${id}` : hint ? `hint-${id}` : undefined} />
      {error
        ? <p id={`err-${id}`} role="alert" className="text-xs text-destructive mt-1.5 flex items-center gap-1"><AlertCircle size={11} aria-hidden="true" />{error}</p>
        : hint ? <p id={`hint-${id}`} className="text-xs text-muted-foreground mt-1.5">{hint}</p> : null}
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <A11yBar {...a} /><SRBanner active={a.s.screenReader} />
      <AppHeader title="Novo Operador" subtitle="Cadastro de Usuário" onBack={onBack} backLabel="Voltar para gestão de usuários" />
      <main className="flex-1 overflow-y-auto scrollbar-thin p-6" role="main">
        <div className="max-w-lg mx-auto">
          <div className="mb-6">
            <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
              <UserPlus size={18} className="text-primary" aria-hidden="true" />
              Dados do Novo Operador
            </h2>
            <p className="text-sm text-muted-foreground mt-1">Preencha os campos para cadastrar o usuário.</p>
          </div>
          <form onSubmit={handleSave} noValidate className="space-y-5">
            <Field id="reg-fullName" label="Nome Completo" value={fullName}
              onChange={setFullName} placeholder="Ex: Ricardo Alves" error={errors.fullName} />
            <Field id="reg-username" label="Nome de Usuário (Login)" value={username}
              onChange={(v) => setUsername(v.toLowerCase().replace(/\s/g, "."))}
              placeholder="Ex: ricardo.alves" error={errors.username}
              hint="Letras minúsculas, números e pontos." mono />
            <Field id="reg-password" label="Senha" value={password}
              onChange={setPassword} type="password" placeholder="Mínimo 6 caracteres" error={errors.password} />
            <div>
              <label htmlFor="reg-profile" className="block text-sm font-semibold text-foreground mb-1.5">Perfil de Acesso</label>
              <select id="reg-profile" value={profile}
                onChange={(e) => setProfile(e.target.value as UserProfile)} className="pdv-input">
                <option value="Operador de Caixa">Operador de Caixa</option>
                <option value="Gerente de Loja">Gerente de Loja</option>
              </select>
            </div>
            <div className="flex gap-3 pt-2">
              <button type="button"
                onClick={() => { setFullName(""); setUsername(""); setPassword(""); setProfile("Operador de Caixa"); setErrors({}); }}
                className="pdv-btn-ghost flex-none px-5 py-2.5">
                <RefreshCw size={14} className="mr-2" aria-hidden="true" />Limpar
              </button>
              <button type="submit" className="pdv-btn-primary flex-1 py-2.5">
                <Check size={16} className="mr-2" aria-hidden="true" />Salvar Cadastro
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
}

// ── Screen: Registration Success ───────────────────────────────────────────────

function RegistrationSuccess({ operator, onRegisterAnother, onLogout, ...a }: {
  operator: Operator; onRegisterAnother: () => void; onLogout: () => void;
} & A11yProps) {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <A11yBar {...a} /><SRBanner active={a.s.screenReader} />
      <AppHeader title="Lumina PDV" subtitle="Painel Administrativo" />
      <main className="flex-1 flex items-center justify-center p-6" role="main" aria-live="polite" aria-atomic="true">
        <div className="w-full max-w-md text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-100 dark:bg-green-900/30 mb-6 shadow-sm" aria-hidden="true">
            <Check size={40} className="text-green-600 dark:text-green-400" strokeWidth={2.5} />
          </div>
          <h1 className="text-2xl font-bold text-foreground uppercase tracking-wide mb-2">Operador Cadastrado com Sucesso</h1>
          <p className="text-muted-foreground text-sm mb-8">O novo usuário já pode acessar o sistema.</p>
          <div className="bg-card border border-border rounded-xl p-5 text-left mb-8">
            <div className="flex items-center gap-3 mb-4 pb-4 border-b border-border">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0" aria-hidden="true">
                <User size={18} className="text-primary" />
              </div>
              <div>
                <p className="font-bold text-foreground">{operator.fullName}</p>
                <p className="text-xs text-muted-foreground font-mono">@{operator.username}</p>
              </div>
            </div>
            <dl className="space-y-2">
              {[
                { label: "Perfil", value: operator.profile },
                { label: "Status", value: "Ativo" },
                { label: "Criado em", value: new Date().toLocaleDateString("pt-BR") },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between">
                  <dt className="text-sm text-muted-foreground">{label}</dt>
                  <dd className="text-sm font-semibold text-foreground">{value}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="flex gap-3">
            <button onClick={onLogout} className="pdv-btn-ghost flex-none px-4" aria-label="Sair do sistema">
              <LogOut size={14} className="mr-1.5" aria-hidden="true" />Sair
            </button>
            <button onClick={onRegisterAnother} className="pdv-btn-primary flex-1" autoFocus>
              <UserPlus size={16} className="mr-2" aria-hidden="true" />+ Cadastrar Outro Operador
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}

// ── Screen: Operator Menu ──────────────────────────────────────────────────────

function OperatorMenu({ onNavigate, onLogout, ...a }: { onNavigate: (s: Screen) => void; onLogout: () => void } & A11yProps) {
  const now = new Date();
  const cards = [
    { icon: ShoppingCart, label: "Nova Venda",       desc: "Registrar atendimento",  shortcut: "Alt+2", screen: "register" as Screen, primary: true },
    { icon: Package,      label: "Produtos",         desc: "Consultar catálogo",     shortcut: "",      screen: null, primary: false },
    { icon: Gamepad2,     label: "Jogos e Créditos", desc: "Créditos para jogos",    shortcut: "",      screen: null, primary: false },
    { icon: Settings,     label: "Configurações",    desc: "Ajustes do sistema",     shortcut: "",      screen: null, primary: false },
    { icon: HelpCircle,   label: "Ajuda",            desc: "Central de suporte",     shortcut: "Alt+0", screen: null, primary: false },
  ];
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <A11yBar {...a} /><SRBanner active={a.s.screenReader} />
      <AppHeader title="Lumina PDV"
        trailing={
          <div className="flex items-center gap-4">
            <span className="text-xs opacity-70 hidden sm:block">
              {now.toLocaleDateString("pt-BR", { weekday: "short", day: "2-digit", month: "short" })} · {now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
            </span>
            <button onClick={onLogout}
              className="text-xs opacity-75 hover:opacity-100 flex items-center gap-1.5 focus:outline-none focus:ring-2 focus:ring-primary-foreground/60 rounded px-1"
              aria-label="Sair">
              <LogOut size={14} aria-hidden="true" /><span className="hidden sm:inline">Sair</span>
            </button>
          </div>
        }
      />
      <main className="flex-1 p-6 max-w-3xl mx-auto w-full" role="main">
        <div className="mb-7">
          <h1 className="text-xl font-bold text-foreground">Bem-vindo ao Lumina PDV</h1>
          <p className="text-muted-foreground text-sm mt-1">Selecione uma opção para continuar</p>
        </div>
        <nav aria-label="Menu principal">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {cards.map((card) => (
              <button key={card.label}
                onClick={() => card.screen && onNavigate(card.screen)}
                disabled={!card.screen}
                aria-label={`${card.label}${card.shortcut ? ` — ${card.shortcut}` : ""}`}
                className={`pdv-menu-card ${card.primary ? "pdv-menu-card-primary" : ""} ${!card.screen ? "opacity-50 cursor-not-allowed hover:translate-y-0 hover:shadow-none" : ""}`}>
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${card.primary ? "bg-primary-foreground/20" : "bg-primary/8"}`} aria-hidden="true">
                  <card.icon size={20} className={card.primary ? "text-primary-foreground" : "text-primary"} />
                </div>
                <span className={`font-semibold text-sm block ${card.primary ? "text-primary-foreground" : "text-foreground"}`}>{card.label}</span>
                <span className={`text-xs mt-0.5 block ${card.primary ? "text-primary-foreground/65" : "text-muted-foreground"}`}>{card.desc}</span>
                {card.shortcut && <span className="text-xs mt-2 block"><kbd className={card.primary ? "pdv-kbd-light" : "pdv-kbd"}>{card.shortcut}</kbd></span>}
              </button>
            ))}
          </div>
        </nav>
        <p className="text-xs text-muted-foreground mt-8 text-center">
          <kbd className="pdv-kbd">Alt+2</kbd> Nova Venda &nbsp;·&nbsp;<kbd className="pdv-kbd">Alt+0</kbd> Guia
        </p>
      </main>
    </div>
  );
}

// ── Screen: Register Sale ──────────────────────────────────────────────────────

function RegisterScreen({ cart, onAdd, onRemove, onQty, onClear, onFinalize, onCancel, ...a }: {
  cart: CartItem[]; onAdd: (p: Product, qty: number) => void;
  onRemove: (id: number) => void; onQty: (id: number, qty: number) => void;
  onClear: () => void; onFinalize: () => void; onCancel: () => void;
} & A11yProps) {
  const [search, setSearch]     = useState("");
  const [cat, setCat]           = useState<Category>("Todos");
  const [selected, setSelected] = useState<Product | null>(null);
  const [qty, setQty]           = useState(1);
  const searchRef               = useRef<HTMLInputElement>(null);

  const cats: Category[] = ["Todos", "Serviços", "Jogos e Créditos", "Informática", "Conveniência"];
  const filtered = PRODUCTS.filter(
    (p) => (cat === "Todos" || p.category === cat) &&
            (p.name.toLowerCase().includes(search.toLowerCase()) || p.barcode.includes(search))
  );
  const total      = cart.reduce((s, i) => s + i.product.price * i.quantity, 0);
  const totalItems = cart.reduce((s, i) => s + i.quantity, 0);

  const handleAdd = () => {
    if (!selected) return;
    onAdd(selected, qty);
    setSelected(null); setQty(1);
    searchRef.current?.focus();
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <A11yBar {...a} /><SRBanner active={a.s.screenReader} />
      <AppHeader title="Registrar Venda" onBack={onCancel} backLabel="Voltar ao menu"
        badge={totalItems > 0 ? `${totalItems} ${totalItems === 1 ? "item" : "itens"}` : undefined} />

      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden min-h-0">

        {/* Left: catalogue */}
        <div className="flex-1 flex flex-col overflow-hidden border-r border-border min-h-0">

          {/* Search + filters */}
          <div className="p-4 border-b border-border space-y-3 shrink-0 bg-card">
            <div className="relative">
              <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" aria-hidden="true" />
              <input ref={searchRef} type="search" value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="PESQUISAR PRODUTO — NOME OU CÓDIGO DE BARRAS"
                className="pdv-input pl-12 pr-14 py-3.5 text-sm font-medium uppercase placeholder:font-normal placeholder:normal-case placeholder:text-sm"
                aria-label="Pesquisar produto por nome ou código de barras"
                autoFocus />
              <button type="button" title="Leitor de código de barras"
                aria-label="Simular leitura de código de barras"
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 rounded-lg hover:bg-muted text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors">
                <Scan size={18} aria-hidden="true" />
              </button>
            </div>
            <div role="group" aria-label="Filtrar por categoria" className="flex flex-wrap gap-1.5">
              {cats.map((c) => (
                <button key={c} onClick={() => setCat(c)} aria-pressed={cat === c}
                  className={`pdv-filter-btn ${cat === c ? "pdv-filter-btn-active" : ""}`}>{c}</button>
              ))}
            </div>
          </div>

          {/* Product grid with photos */}
          <div className="flex-1 overflow-y-auto scrollbar-thin p-4" role="list" aria-label="Catálogo de produtos">
            {filtered.length === 0 ? (
              <div className="text-center text-muted-foreground py-14">
                <Package size={36} className="mx-auto mb-3 opacity-30" aria-hidden="true" />
                <p className="text-sm">Nenhum produto encontrado</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3">
                {filtered.map((p) => {
                  const isSel = selected?.id === p.id;
                  return (
                    <div key={p.id} role="listitem"
                      className={`flex flex-col rounded-xl overflow-hidden border-2 transition-all bg-card ${isSel ? "border-primary shadow-md" : "border-border hover:border-primary/40 hover:shadow-sm"}`}>
                      {/* Photo */}
                      <button onClick={() => { setSelected(p); setQty(1); }}
                        aria-label={`Selecionar ${p.name} — ${fmt(p.price)}`}
                        aria-pressed={isSel}
                        className="focus:outline-none relative block">
                        <div className="relative w-full aspect-square bg-muted overflow-hidden">
                          <img src={p.photo} alt={p.name} className="w-full h-full object-cover" loading="lazy" />
                          {isSel && (
                            <div className="absolute inset-0 bg-primary/20 flex items-center justify-center">
                              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                                <Check size={18} className="text-primary-foreground" aria-hidden="true" />
                              </div>
                            </div>
                          )}
                        </div>
                      </button>
                      {/* Info */}
                      <div className="p-2.5 flex flex-col gap-0.5 flex-1">
                        <span className="text-[10px] text-muted-foreground truncate">{p.category}</span>
                        <span className="text-xs font-semibold text-foreground leading-snug line-clamp-2">{p.name}</span>
                        <span className="text-[10px] text-muted-foreground font-mono truncate" aria-label={`Código: ${p.barcode}`}>
                          Cód: {p.barcode}
                        </span>
                        <span className="font-bold text-primary text-sm font-mono mt-0.5">{fmt(p.price)}</span>
                        <button
                          onClick={() => { setSelected(p); setQty(1); }}
                          aria-label={`Adicionar ${p.name}`}
                          className={`mt-1.5 w-full flex items-center justify-center gap-1 rounded-lg py-1.5 text-xs font-bold transition-all focus:outline-none focus:ring-2 focus:ring-ring ${isSel ? "bg-primary text-primary-foreground" : "bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground"}`}>
                          <Plus size={12} aria-hidden="true" />
                          ADICIONAR
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Add-to-cart panel */}
          {selected && (
            <div className="border-t-2 border-primary/30 p-4 bg-secondary/50 shrink-0"
              role="region" aria-label="Adicionar item selecionado" aria-live="polite">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-lg overflow-hidden border-2 border-border shrink-0 bg-muted" aria-hidden="true">
                  <img src={selected.photo} alt="" className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm text-foreground truncate">{selected.name}</p>
                  <p className="text-primary font-bold font-mono">{fmt(selected.price)}</p>
                </div>
                <button onClick={() => setSelected(null)} aria-label="Cancelar seleção"
                  className="p-1 rounded hover:bg-border text-muted-foreground shrink-0">
                  <X size={16} aria-hidden="true" />
                </button>
              </div>
              <div className="flex items-center gap-2">
                <label htmlFor="qty-input" className="text-sm font-semibold shrink-0">Qtd:</label>
                <div className="flex items-center gap-1" role="group" aria-label="Quantidade">
                  <button onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Diminuir"
                    className="pdv-qty-btn"><Minus size={13} aria-hidden="true" /></button>
                  <input id="qty-input" type="number" min={1} max={99} value={qty}
                    onChange={(e) => setQty(Math.max(1, Math.min(99, parseInt(e.target.value, 10) || 1)))}
                    className="pdv-input w-14 text-center py-1.5 text-sm" />
                  <button onClick={() => setQty((q) => Math.min(99, q + 1))} aria-label="Aumentar"
                    className="pdv-qty-btn"><Plus size={13} aria-hidden="true" /></button>
                </div>
                <button onClick={handleAdd} className="pdv-btn-primary flex-1 py-2">
                  <Plus size={15} className="mr-1.5" aria-hidden="true" />Confirmar
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right: cart */}
        <div className="w-full lg:w-80 flex flex-col bg-card shrink-0 border-t lg:border-t-0 border-border"
          role="region" aria-label="Carrinho">
          <div className="px-4 py-3 border-b border-border flex items-center justify-between shrink-0">
            <h2 className="font-semibold text-foreground flex items-center gap-2 text-sm">
              <ShoppingCart size={16} aria-hidden="true" />Itens da Venda
            </h2>
            {cart.length > 0 && (
              <button onClick={onClear}
                className="text-xs text-destructive hover:underline focus:outline-none focus:ring-2 focus:ring-destructive rounded"
                aria-label="Limpar carrinho">Limpar tudo</button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto scrollbar-thin min-h-0" aria-live="polite">
            {cart.length === 0 ? (
              <div className="text-center text-muted-foreground py-12 px-4">
                <ShoppingCart size={32} className="mx-auto mb-2.5 opacity-25" aria-hidden="true" />
                <p className="text-sm font-medium">Carrinho vazio</p>
                <p className="text-xs mt-1 opacity-70">Selecione produtos à esquerda</p>
              </div>
            ) : (
              <table className="w-full text-sm">
                <thead className="bg-muted/50 sticky top-0">
                  <tr>
                    <th scope="col" className="text-left text-xs font-semibold text-muted-foreground px-3 py-2">Produto</th>
                    <th scope="col" className="text-center text-xs font-semibold text-muted-foreground px-2 py-2 w-20">Qtd</th>
                    <th scope="col" className="text-right text-xs font-semibold text-muted-foreground px-3 py-2">Subtotal</th>
                    <th scope="col" className="w-7 px-1 py-2"><span className="sr-only">Remover</span></th>
                  </tr>
                </thead>
                <tbody>
                  {cart.map((item) => (
                    <tr key={item.product.id} className="border-t border-border">
                      <td className="px-3 py-2.5">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-md overflow-hidden shrink-0 bg-muted border border-border" aria-hidden="true">
                            <img src={item.product.photo} alt="" className="w-full h-full object-cover" loading="lazy" />
                          </div>
                          <div className="min-w-0">
                            <span className="font-medium text-foreground text-xs block leading-snug" style={{ maxWidth: "100px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{item.product.name}</span>
                            <span className="text-xs text-muted-foreground font-mono">{fmt(item.product.price)}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-2 py-2">
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={() => onQty(item.product.id, item.quantity - 1)} aria-label={`Diminuir ${item.product.name}`}
                            className="w-5 h-5 flex items-center justify-center rounded bg-muted hover:bg-border text-foreground focus:outline-none focus:ring-1 focus:ring-ring">
                            <Minus size={10} aria-hidden="true" />
                          </button>
                          <span className="text-xs font-bold w-5 text-center tabular-nums">{item.quantity}</span>
                          <button onClick={() => onQty(item.product.id, item.quantity + 1)} aria-label={`Aumentar ${item.product.name}`}
                            className="w-5 h-5 flex items-center justify-center rounded bg-muted hover:bg-border text-foreground focus:outline-none focus:ring-1 focus:ring-ring">
                            <Plus size={10} aria-hidden="true" />
                          </button>
                        </div>
                      </td>
                      <td className="px-3 py-2 text-right text-xs font-bold text-foreground font-mono tabular-nums">
                        {fmt(item.product.price * item.quantity)}
                      </td>
                      <td className="px-1 py-2">
                        <button onClick={() => onRemove(item.product.id)} aria-label={`Remover ${item.product.name}`}
                          className="p-1 text-muted-foreground hover:text-destructive rounded focus:outline-none focus:ring-1 focus:ring-destructive">
                          <Trash2 size={13} aria-hidden="true" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          <div className="border-t border-border p-4 space-y-3 shrink-0 bg-card">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-muted-foreground">Total Geral</span>
              <span className="text-xl font-bold text-primary font-mono tabular-nums" aria-live="polite"
                aria-label={`Total: ${fmt(total)}`}>{fmt(total)}</span>
            </div>
            <button id="finalize-btn" onClick={onFinalize} disabled={cart.length === 0}
              className="pdv-btn-success w-full py-2.5" aria-label="Finalizar venda" aria-keyshortcuts="Alt+4">
              <Receipt size={16} className="mr-2" aria-hidden="true" />
              Finalizar Venda
              <kbd className="ml-auto pdv-kbd-light text-xs" aria-hidden="true">Alt+4</kbd>
            </button>
            <button onClick={onCancel} className="pdv-btn-ghost w-full py-2" aria-label="Cancelar">Cancelar</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Receipt Modal ──────────────────────────────────────────────────────────────

function ReceiptModal({ cart, payment, saleNumber, customerName, onClose }: {
  cart: CartItem[]; payment: PaymentMethod; saleNumber: string;
  customerName: string; onClose: () => void;
}) {
  const total      = cart.reduce((acc, i) => acc + i.product.price * i.quantity, 0);
  const totalItems = cart.reduce((acc, i) => acc + i.quantity, 0);
  const now        = new Date();
  const dateStr    = now.toLocaleDateString("pt-BR");
  const timeStr    = now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const displayName = customerName.trim() || "CLIENTE BALCÃO";

  const handlePrint = () => {
    const win = window.open("", "_blank", "width=440,height=750");
    if (!win) return;
    win.document.write(`<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"/>
<title>Recibo ${saleNumber}</title>
<style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:'Courier New',monospace;font-size:12px;color:#000;background:#fff;padding:20px 16px;max-width:380px;margin:0 auto}.center{text-align:center}.bold{font-weight:bold}.dashed{border-top:1px dashed #555;margin:8px 0}.solid{border-top:2px solid #000;margin:8px 0}.row{display:flex;justify-content:space-between;padding:2px 0}.total-row{display:flex;justify-content:space-between;font-weight:bold;font-size:14px;padding:5px 0}.payment-box{border:2px solid #000;padding:6px 10px;margin:6px 0;text-align:center}h1{font-size:16px;font-weight:bold;text-align:center;text-transform:uppercase;letter-spacing:.08em;margin-bottom:2px}@media print{body{padding:0}}</style>
</head><body>
<h1>Lumina PDV</h1>
<p class="center" style="font-size:10px">LAN HOUSE — SISTEMA DE PONTO DE VENDA</p>
<p class="center" style="font-size:10px">CNPJ: 00.000.000/0001-00</p>
<div class="dashed"></div>
<div class="row"><span>Cupom Nº:</span><span class="bold">${saleNumber}</span></div>
<div class="row"><span>Data:</span><span>${dateStr}</span></div>
<div class="row"><span>Hora:</span><span>${timeStr}</span></div>
<div class="row"><span>Cliente:</span><span class="bold">${displayName}</span></div>
<div class="dashed"></div>
<p class="bold" style="margin-bottom:6px;font-size:11px;text-transform:uppercase">Itens</p>
${cart.map(item => `<div class="row"><span style="flex:1;padding-right:8px">${item.quantity}x ${item.product.name}</span><span>${fmt(item.product.price * item.quantity)}</span></div><div class="row" style="color:#555;font-size:10px;padding-bottom:4px"><span>  Cód: ${item.product.barcode}</span><span>V.Unit: ${fmt(item.product.price)}</span></div>`).join("")}
<div class="solid"></div>
<div class="row"><span>Total de itens:</span><span>${totalItems}</span></div>
<div class="total-row"><span>TOTAL GERAL:</span><span>${fmt(total)}</span></div>
<div class="dashed"></div>
<div class="payment-box"><p style="font-size:9px;font-weight:bold;text-transform:uppercase;letter-spacing:.1em;color:#555;margin-bottom:4px">Forma de Pagamento</p><p style="font-size:14px;font-weight:bold;text-transform:uppercase">${payment}</p></div>
<div class="dashed"></div>
<p class="center" style="margin-top:10px;font-size:10px">Obrigado pela preferência!</p>
<p class="center" style="font-size:9px;color:#555">Lumina PDV · www.luminapdv.com.br</p>
</body></html>`);
    win.document.close(); win.focus();
    setTimeout(() => win.print(), 400);
  };

  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog" aria-modal="true" aria-labelledby="receipt-modal-title">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} aria-hidden="true" />
      <div className="relative bg-card border border-border rounded-2xl shadow-2xl w-full max-w-sm flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border shrink-0">
          <h2 id="receipt-modal-title" className="font-bold text-foreground flex items-center gap-2 text-sm">
            <Receipt size={16} className="text-primary" aria-hidden="true" />Prévia do Recibo
          </h2>
          <button onClick={onClose} aria-label="Fechar (Esc)"
            className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring">
            <X size={16} aria-hidden="true" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto scrollbar-thin p-5">
          <div className="bg-white text-black rounded-lg p-5 border-2 border-dashed border-gray-300"
            style={{ fontFamily: "'Courier New',Courier,monospace" }}>
            <div className="text-center mb-3">
              <p className="font-black text-sm tracking-wider uppercase">Lumina PDV</p>
              <p className="text-[10px] text-gray-600">Lan House — Sistema de Ponto de Venda</p>
              <p className="text-[10px] text-gray-600">CNPJ: 00.000.000/0001-00</p>
            </div>
            <div className="border-t border-dashed border-gray-400 my-2" />
            <div className="space-y-0.5 text-xs mb-2">
              {[["Cupom Nº", saleNumber], ["Data", dateStr], ["Hora", timeStr], ["Cliente", displayName]].map(([l, v]) => (
                <div key={l} className="flex justify-between">
                  <span className="text-gray-600">{l}:</span><span className="font-bold">{v}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-dashed border-gray-400 my-2" />
            <p className="font-bold uppercase text-[10px] tracking-widest mb-1.5">Itens</p>
            <div className="space-y-1.5 text-xs">
              {cart.map((item) => (
                <div key={item.product.id}>
                  <div className="flex justify-between gap-1">
                    <span className="flex-1 leading-tight">{item.quantity}x {item.product.name}</span>
                    <span className="shrink-0 font-semibold">{fmt(item.product.price * item.quantity)}</span>
                  </div>
                  <div className="flex justify-between text-[9px] text-gray-500 pl-2">
                    <span>Cód: {item.product.barcode}</span>
                    <span>V.Unit: {fmt(item.product.price)}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t-2 border-gray-600 my-2" />
            <div className="flex justify-between text-[10px] text-gray-600 mb-0.5">
              <span>Total de itens:</span><span>{totalItems}</span>
            </div>
            <div className="flex justify-between font-black text-sm">
              <span>TOTAL GERAL:</span><span>{fmt(total)}</span>
            </div>
            <div className="border-t border-dashed border-gray-400 my-2" />
            <div className="border-2 border-gray-600 rounded px-3 py-2 text-center">
              <p className="text-[9px] font-semibold uppercase tracking-widest text-gray-600 mb-1">Forma de Pagamento</p>
              <p className="font-black text-sm uppercase">{payment}</p>
            </div>
            <div className="border-t border-dashed border-gray-400 my-3" />
            <div className="text-center">
              <p className="text-[10px] text-gray-500">Obrigado pela preferência!</p>
              <p className="text-[9px] text-gray-400">Lumina PDV · www.luminapdv.com.br</p>
            </div>
          </div>
        </div>
        <div className="px-5 py-4 border-t border-border flex gap-3 shrink-0">
          <button onClick={onClose} className="pdv-btn-ghost flex-none px-4">
            <X size={14} className="mr-1.5" aria-hidden="true" />Fechar (Esc)
          </button>
          <button onClick={handlePrint} className="pdv-btn-primary flex-1">
            <Printer size={16} className="mr-2" aria-hidden="true" />Imprimir Recibo
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Screen: Review ─────────────────────────────────────────────────────────────

function ReviewScreen({ cart, onConfirm, onBack, ...a }: {
  cart: CartItem[]; onConfirm: (pm: PaymentMethod, name: string) => void; onBack: () => void;
} & A11yProps) {
  const [payment, setPayment]           = useState<PaymentMethod>("");
  const [customerName, setCustomerName] = useState("");
  const total      = cart.reduce((acc, i) => acc + i.product.price * i.quantity, 0);
  const totalItems = cart.reduce((acc, i) => acc + i.quantity, 0);
  const paymentMethods: { value: PaymentMethod; label: string }[] = [
    { value: "Dinheiro",          label: "💵 Dinheiro" },
    { value: "Pix",               label: "⚡ Pix" },
    { value: "Cartão de Débito",  label: "💳 Cartão Débito" },
    { value: "Cartão de Crédito", label: "💳 Cartão Crédito" },
  ];
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <A11yBar {...a} /><SRBanner active={a.s.screenReader} />
      <AppHeader title="Resumo da Venda" onBack={onBack} backLabel="Voltar para registrar venda" />
      <main className="flex-1 overflow-y-auto scrollbar-thin p-5" role="main">
        <div className="max-w-xl mx-auto space-y-5">
          {/* Customer name */}
          <section aria-labelledby="customer-heading">
            <div className="bg-card rounded-xl border border-border p-5">
              <h2 id="customer-heading" className="font-semibold text-foreground text-sm mb-3 flex items-center gap-2">
                <UserCircle size={15} className="text-primary" aria-hidden="true" />
                Nome do Cliente
                <span className="text-xs font-normal text-muted-foreground">(opcional)</span>
              </h2>
              <div className="relative">
                <User size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" aria-hidden="true" />
                <input id="customer-name" type="text" value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Ex: João Silva — deixe em branco para 'CLIENTE BALCÃO'"
                  className="pdv-input pl-9" autoComplete="off" />
              </div>
            </div>
          </section>
          {/* Items */}
          <section aria-labelledby="review-items-heading">
            <div className="bg-card rounded-xl border border-border overflow-hidden">
              <div className="px-5 py-3.5 border-b border-border flex items-center justify-between">
                <h2 id="review-items-heading" className="font-semibold text-foreground text-sm">Itens da Venda</h2>
                <span className="text-xs text-muted-foreground">{totalItems} {totalItems === 1 ? "item" : "itens"}</span>
              </div>
              <table className="w-full text-sm">
                <thead className="bg-muted/50">
                  <tr>
                    <th scope="col" className="text-left text-xs font-semibold text-muted-foreground px-5 py-2.5">Produto</th>
                    <th scope="col" className="text-center text-xs font-semibold text-muted-foreground px-3 py-2.5 w-12">Qtd</th>
                    <th scope="col" className="text-right text-xs font-semibold text-muted-foreground px-3 py-2.5">Unit.</th>
                    <th scope="col" className="text-right text-xs font-semibold text-muted-foreground px-5 py-2.5">Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  {cart.map((item, idx) => (
                    <tr key={item.product.id} className={`border-t border-border ${idx % 2 === 1 ? "bg-muted/20" : ""}`}>
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-2.5">
                          <div className="w-9 h-9 rounded-lg overflow-hidden shrink-0 border-2 border-border bg-muted" aria-hidden="true">
                            <img src={item.product.photo} alt="" className="w-full h-full object-cover" loading="lazy" />
                          </div>
                          <div className="min-w-0">
                            <span className="font-medium text-foreground text-sm block truncate">{item.product.name}</span>
                            <span className="text-[10px] text-muted-foreground font-mono">Cód: {item.product.barcode}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-3 text-center text-muted-foreground tabular-nums">{item.quantity}</td>
                      <td className="px-3 py-3 text-right text-muted-foreground font-mono tabular-nums text-xs">{fmt(item.product.price)}</td>
                      <td className="px-5 py-3 text-right font-semibold text-foreground font-mono tabular-nums">{fmt(item.product.price * item.quantity)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="border-t-2 border-border bg-muted/30">
                  <tr>
                    <td colSpan={3} className="px-5 py-4 font-bold text-foreground">Total Geral</td>
                    <td className="px-5 py-4 text-right font-bold text-lg text-primary font-mono tabular-nums">{fmt(total)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </section>
          {/* Payment */}
          <section aria-labelledby="payment-heading">
            <div className="bg-card rounded-xl border border-border p-5">
              <h2 id="payment-heading" className="font-semibold text-foreground text-sm mb-4">Forma de Pagamento</h2>
              <div role="radiogroup" aria-labelledby="payment-heading" aria-required="true" className="grid grid-cols-2 gap-2.5">
                {paymentMethods.map(({ value, label }) => (
                  <button key={value} role="radio" aria-checked={payment === value}
                    onClick={() => setPayment(value)}
                    className={`pdv-payment-btn text-sm ${payment === value ? "pdv-payment-btn-active" : ""}`}>
                    {payment === value && <Check size={13} className="mr-2 shrink-0" aria-hidden="true" />}
                    {label}
                  </button>
                ))}
              </div>
              {!payment && (
                <p className="flex items-center gap-1.5 text-xs text-muted-foreground mt-3" role="status">
                  <AlertCircle size={12} aria-hidden="true" />Selecione uma forma de pagamento para continuar
                </p>
              )}
            </div>
          </section>
          <div className="flex gap-3 pb-6">
            <button onClick={onBack} className="pdv-btn-ghost flex-none px-5">
              <ArrowLeft size={15} className="mr-2" aria-hidden="true" />Voltar
            </button>
            <button id="confirm-btn"
              onClick={() => payment && onConfirm(payment, customerName)}
              disabled={!payment}
              className="pdv-btn-success flex-1"
              aria-disabled={!payment} aria-keyshortcuts="Alt+4">
              <Check size={16} className="mr-2" aria-hidden="true" />Confirmar Venda (Alt+4)
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}

// ── Screen: Confirmation ───────────────────────────────────────────────────────

function ConfirmationScreen({ cart, payment, saleNumber, customerName, onNewSale, onMenu, ...a }: {
  cart: CartItem[]; payment: PaymentMethod; saleNumber: string; customerName: string;
  onNewSale: () => void; onMenu: () => void;
} & A11yProps) {
  const [showReceipt, setShowReceipt] = useState(false);
  const total      = cart.reduce((acc, i) => acc + i.product.price * i.quantity, 0);
  const totalItems = cart.reduce((acc, i) => acc + i.quantity, 0);
  const now        = new Date();
  const displayName = customerName.trim() || "CLIENTE BALCÃO";
  const rows = [
    { label: "Número da Venda",    value: saleNumber,  mono: true },
    { label: "Data",               value: now.toLocaleDateString("pt-BR"), mono: false },
    { label: "Hora",               value: now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }), mono: true },
    { label: "Cliente",            value: displayName,  mono: false },
    { label: "Qtd. de Itens",      value: `${totalItems} ${totalItems === 1 ? "item" : "itens"}`, mono: false },
    { label: "Forma de Pagamento", value: String(payment), mono: false },
  ];
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <A11yBar {...a} /><SRBanner active={a.s.screenReader} />
      <AppHeader title="Lumina PDV" />
      <main className="flex-1 overflow-y-auto scrollbar-thin flex items-center justify-center p-6"
        role="main" aria-live="polite" aria-atomic="true">
        <div className="w-full max-w-md">
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/30 mb-4 shadow-sm" aria-hidden="true">
              <Check size={34} className="text-green-600 dark:text-green-400" strokeWidth={2.5} />
            </div>
            <h1 className="text-xl font-bold text-foreground uppercase tracking-wide">Venda Registrada com Sucesso!</h1>
            <p className="text-muted-foreground text-sm mt-1.5">Atendimento concluído.</p>
          </div>
          <div className="bg-card rounded-xl border border-border p-5 mb-4">
            <dl className="space-y-0">
              {rows.map(({ label, value, mono }, i) => (
                <div key={label} className={`flex justify-between items-center py-2.5 ${i > 0 ? "border-t border-border" : ""}`}>
                  <dt className="text-sm text-muted-foreground">{label}</dt>
                  <dd className={`text-sm font-semibold text-foreground truncate ml-4 ${mono ? "font-mono" : ""}`}>{value}</dd>
                </div>
              ))}
              <div className="flex justify-between items-center py-3 border-t-2 border-border mt-1">
                <dt className="font-bold text-foreground">Valor Total</dt>
                <dd className="text-xl font-bold text-primary font-mono tabular-nums">{fmt(total)}</dd>
              </div>
            </dl>
          </div>
          <button onClick={() => setShowReceipt(true)}
            className="w-full mb-4 flex items-center justify-center gap-2 rounded-xl border-2 border-dashed border-primary/40 bg-primary/5 text-primary font-semibold py-3 text-sm hover:bg-primary/10 hover:border-primary/60 transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
            aria-label="Visualizar e imprimir recibo">
            <Eye size={16} aria-hidden="true" />Visualizar Recibo<Printer size={16} className="opacity-60" aria-hidden="true" />
          </button>
          <div className="flex gap-3">
            <button onClick={onMenu} className="pdv-btn-ghost flex-none px-5">Menu</button>
            <button onClick={onNewSale} className="pdv-btn-primary flex-1 py-2.5" autoFocus>
              <Plus size={16} className="mr-2" aria-hidden="true" />Iniciar Nova Venda
            </button>
          </div>
          <p className="text-center text-xs text-muted-foreground mt-5">
            <kbd className="pdv-kbd">Alt+3</kbd> Nova Venda &nbsp;·&nbsp;<kbd className="pdv-kbd">Alt+1</kbd> Menu
          </p>
        </div>
      </main>
      {showReceipt && (
        <ReceiptModal cart={cart} payment={payment} saleNumber={saleNumber}
          customerName={customerName} onClose={() => setShowReceipt(false)} />
      )}
    </div>
  );
}

// ── Root ───────────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen]               = useState<Screen>("login");
  const [cart, setCart]                   = useState<CartItem[]>([]);
  const [confirmedCart, setConfirmedCart] = useState<CartItem[]>([]);
  const [payment, setPayment]             = useState<PaymentMethod>("");
  const [saleNumber, setSaleNumber]       = useState("");
  const [customerName, setCustomerName]   = useState("");
  const [operators, setOperators]         = useState<Operator[]>(INITIAL_OPERATORS);
  const [lastOperator, setLastOperator]   = useState<Operator | null>(null);
  const [showKbdGuide, setShowKbdGuide]   = useState(false);

  const [settings, setSettings] = useState<A11ySettings>({
    theme: "light", highContrast: false, fontSize: 18, screenReader: false,
  });

  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty("--font-size", `${settings.fontSize}px`);
    root.classList.toggle("dark", settings.theme === "dark");
    root.classList.toggle("high-contrast", settings.highContrast);
  }, [settings]);

  useEffect(() => {
    const isManager = ["manager-dashboard", "user-management", "operator-registration", "registration-success"].includes(screen);
    const handle = (e: KeyboardEvent) => {
      if (!e.altKey) return;
      switch (e.key) {
        case "1": e.preventDefault(); if (screen !== "login") setScreen(isManager ? "manager-dashboard" : "operator-menu"); break;
        case "2": e.preventDefault(); if (!isManager && screen !== "login") setScreen("register"); break;
        case "3": e.preventDefault(); if (!isManager && screen !== "login") { setCart([]); setScreen("register"); } break;
        case "4": e.preventDefault(); document.getElementById("confirm-btn")?.click(); document.getElementById("finalize-btn")?.click(); break;
        case "0": e.preventDefault(); setShowKbdGuide(true); break;
      }
    };
    window.addEventListener("keydown", handle);
    return () => window.removeEventListener("keydown", handle);
  }, [screen]);

  const toggleTheme = useCallback(() => setSettings(p => ({ ...p, theme: p.theme === "light" ? "dark" : "light" })), []);
  const fontUp      = useCallback(() => setSettings(p => ({ ...p, fontSize: Math.min(p.fontSize + 2, 26) })), []);
  const fontDown    = useCallback(() => setSettings(p => ({ ...p, fontSize: Math.max(p.fontSize - 2, 14) })), []);
  const fontReset   = useCallback(() => setSettings(p => ({ ...p, fontSize: 18 })), []);
  const toggleHC    = useCallback(() => setSettings(p => ({ ...p, highContrast: !p.highContrast })), []);
  const toggleSR    = useCallback(() => setSettings(p => ({ ...p, screenReader: !p.screenReader })), []);
  const showKbd     = useCallback(() => setShowKbdGuide(true), []);

  const addToCart = useCallback((product: Product, qty: number) => {
    setCart(prev => {
      const ex = prev.find(i => i.product.id === product.id);
      if (ex) return prev.map(i => i.product.id === product.id ? { ...i, quantity: i.quantity + qty } : i);
      return [...prev, { product, quantity: qty }];
    });
  }, []);
  const removeFromCart = useCallback((id: number) => setCart(prev => prev.filter(i => i.product.id !== id)), []);
  const updateQty = useCallback((id: number, qty: number) => {
    if (qty <= 0) setCart(prev => prev.filter(i => i.product.id !== id));
    else setCart(prev => prev.map(i => i.product.id === id ? { ...i, quantity: qty } : i));
  }, []);

  const handleConfirm = useCallback((pm: PaymentMethod, name: string) => {
    setConfirmedCart([...cart]);
    setPayment(pm); setCustomerName(name);
    setSaleNumber(genSaleNumber());
    setCart([]); setScreen("confirmation");
  }, [cart]);

  const handleSaveOperator = useCallback((op: Omit<Operator, "id" | "avatar">) => {
    const newOp: Operator = { ...op, id: Date.now(), avatar: "" };
    setOperators(prev => [...prev, newOp]);
    setLastOperator(newOp);
    setScreen("registration-success");
  }, []);

  const a: A11yProps = {
    s: settings, onToggleTheme: toggleTheme, onFontUp: fontUp, onFontDown: fontDown,
    onFontReset: fontReset, onToggleHC: toggleHC, onToggleSR: toggleSR, onShowKbdGuide: showKbd,
  };

  const renderScreen = () => {
    switch (screen) {
      case "login":
        return <LoginScreen onLogin={(role) => setScreen(role === "manager" ? "manager-dashboard" : "operator-menu")} {...a} />;
      case "manager-dashboard":
        return <ManagerDashboard onGoToUsers={() => setScreen("user-management")} onLogout={() => setScreen("login")} {...a} />;
      case "user-management":
        return <UserManagement operators={operators} onAdd={() => setScreen("operator-registration")}
          onDelete={(id) => setOperators(prev => prev.filter(o => o.id !== id))}
          onBack={() => setScreen("manager-dashboard")} {...a} />;
      case "operator-registration":
        return <OperatorRegistration onSave={handleSaveOperator} onBack={() => setScreen("user-management")} {...a} />;
      case "registration-success":
        return lastOperator
          ? <RegistrationSuccess operator={lastOperator} onRegisterAnother={() => setScreen("operator-registration")} onLogout={() => setScreen("login")} {...a} />
          : null;
      case "operator-menu":
        return <OperatorMenu onNavigate={setScreen} onLogout={() => setScreen("login")} {...a} />;
      case "register":
        return <RegisterScreen cart={cart} onAdd={addToCart} onRemove={removeFromCart} onQty={updateQty}
          onClear={() => setCart([])} onFinalize={() => setScreen("review")}
          onCancel={() => setScreen("operator-menu")} {...a} />;
      case "review":
        return <ReviewScreen cart={cart} onConfirm={handleConfirm} onBack={() => setScreen("register")} {...a} />;
      case "confirmation":
        return <ConfirmationScreen cart={confirmedCart} payment={payment} saleNumber={saleNumber}
          customerName={customerName} onNewSale={() => { setCart([]); setScreen("register"); }}
          onMenu={() => setScreen("operator-menu")} {...a} />;
    }
  };

  return (
    <>
      {renderScreen()}
      {showKbdGuide && <KeyboardGuide onClose={() => setShowKbdGuide(false)} />}
    </>
  );
}
