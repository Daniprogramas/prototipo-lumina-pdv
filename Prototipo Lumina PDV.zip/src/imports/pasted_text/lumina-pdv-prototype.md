Atuar como um Designer de UI/UX especialista em interfaces comerciais minimalistas e Acessibilidade (WCAG 2.1 - Foco em Baixa Visão) para gerar o protótipo executável de alta fidelidade do sistema "Lumina PDV" (Focado em uma Lan House de pequeno porte). Este comando unifica a Estória EU1 (Cadastro de Operadores pelo Gestor) e a Estória EU4 (Registrar Venda pelo Operador).

--- REGRAS GERAIS DE DESIGN E QUALIDADE ---
- Estilo: Ultra-minimalista, profissional e comercial. Muito espaço em branco, sem poluição visual, sem sombras pesadas ou gradientes escolares. Apenas linhas e preenchimentos sólidos de alto impacto visual.
- Tipografia: Proporcional, legível e equilibrada. Fonte padrão grande (mínimo 18px para textos base). Títulos maiores e destacados. Use fontes como Inter ou Roboto para a UI e JetBrains Mono ou Courier para valores monetários e recibos.
- Persistência: O estado das configurações visuais deve ser mantido ao navegar por qualquer tela.

--- BARRA GLOBAL DE ACESSIBILIDADE PERSISTENTE ---
Em TODAS as telas do sistema, inclua uma barra de ferramentas (superior ou lateral) com componentes explicitamente clicáveis e interativos:
1. Botão [MODO CLARO / DARK] (Alternador instantâneo de tema)
2. Botão [ALTO CONTRASTE] (Ativa paleta independente, ex: fundo preto e letras amarelas)
3. Botão [A+] (Aumentar fonte proporcionalmente)
4. Botão [A-] (Diminuir fonte proporcionalmente)
5. Botão [RESTAURAR FONTE] (Volta ao tamanho padrão de 18px)
6. Botão [LEITOR DE TELA: ATIVO/INATIVO] (Toggle com ARIA-labels simulados)
7. Botão [GUIA DE TECLADO] (Exibe legenda dos atalhos ativos: Alt+1 Menu | Alt+2 Nova Venda | Alt+3 Limpar | Alt+4 Confirmar)

--- CREDENCIAIS DE VALIDAÇÃO DO LOGIN ---
- Perfil GESTOR: Usuário "sara.gerente" | Senha "LuminaGestor2026" -> Direciona para o Fluxo Administrativo (EU1).
- Perfil OPERADOR PADRÃO: Usuário "operador.lan" | Senha "LuminaLan2026" (ou qualquer operador fictício criado pelo gestor) -> Direciona para o Fluxo de Vendas (EU4).

--- ESTRUTURA DE TELAS E CONEXÕES DO PROTÓTIPO ---

TELA 1 – LOGIN UNIFICADO (PONTO DE ENTRADA)
- Elementos Centrais: Logo Lumina PDV, Campo "USUÁRIO", Campo "SENHA" e o Botão "[ ENTRAR ]".
- Presença da Barra Global de Acessibilidade.
- Comportamento de Fluxo: 
  * Se inserido as credenciais do Gestor (sara.gerente), o botão Entrar navega para a TELA 2A (Menu do Gestor).
  * Se inserido as credenciais do Operador (operador.lan), o botão Entrar navega para a TELA 2B (Menu do Operador).

================ FLUXO DO GESTOR (EU1 - CADASTRO) ================

TELA 2A – DASHBOARD DO GESTOR (MENU ADMINISTRATIVO)
- Cabeçalho: Identificação "GERENTE SARA - UNIDADE CENTRAL".
- Área Central: Card de grande destaque: "[ IR PARA GESTÃO E CADASTRO DE OPERADORES ]". Atalhos para gerenciamento de turnos e logs.
- Interação: Clicar no card leva para a TELA 3A.

TELA 3A – FORMULÁRIO DE CADASTRO DE USUÁRIOS
- Lado Esquerdo: Lista minimalista de "Operadores Ativos" (Ex: Francisco de Assis - Gerente; Maria Aparecida - Caixa).
- Lado Direito: Formulário com campos grandes e espaçados: "NOME COMPLETO", "NOME DE USUÁRIO (LOGIN)", "SENHA" e Dropdown "PERFIL DE ACESSO" (Opções selecionáveis: Operador de Caixa ou Gerente de Loja).
- Base: Botões "[ SALVAR CADASTRO ]" e "[ LIMPAR ]".
- Interação: Clicar em Salvar simula a gravação e navega para a TELA 4A.

TELA 4A – CONFIRMAÇÃO DE CADASTRO DO OPERADOR
- Mensagem centralizada gigante com ícone de sucesso: "OPERADOR CADASTRADO COM SUCESSO".
- Quadro com o resumo dos dados que o gestor acabou de criar (Ex: Ricardo Alves | Perfil: Operador de Caixa).
- Botões: "[ + CADASTRAR OUTRO OPERADOR ]" (Volta para a 3A) e "[ SAIR / VOLTAR AO LOGIN ]" (Volta para a TELA 1).

================ FLUXO DO OPERADOR (EU4 - REGISTRAR VENDA) ================

TELA 2B – MENU PRINCIPAL DO OPERADOR
- Exibir mensagem clara: "Bem-vindo ao Lumina PDV".
- Cards Grandes de Navegação: [NOVA VENDA (Alt + 2)], [PRODUTOS], [SERVIÇOS], [JOGOS E CRÉDITOS], [CONFIGURAÇÕES], [AJUDA].
- Interação: Clicar em "NOVA VENDA" abre a TELA 3B.

TELA 3B – REGISTRAR VENDA (INTERFACE OPERACIONAL DINÂMICA)
- Barra Superior do PDV: Campo de Pesquisa de produtos e Filtros Rápidos por Categoria (Serviços, Jogos e Créditos, Informática, Conveniência).
- Catálogo de Itens Simulados para seleção (Exibir em grade ou lista minimalista com botão [ADICIONAR]):
  * SERVIÇOS: 30 Minutos Computador (R$ 4,00) | 1 Hora Computador (R$ 8,00) | Impressão P&B (R$ 0,50) | Impressão Colorida (R$ 2,00) | Digitalização (R$ 1,50) | Encadernação (R$ 5,00)
  * JOGOS E CRÉDITOS: FF 100 Diamantes (R$ 4,49) | FF 310 Diamantes (R$ 13,99) | Roblox 400 Robux (R$ 25,00) | Roblox 800 Robux (R$ 50,00) | Crédito LOL (R$ 20,00) | Steam Wallet (R$ 30,00)
  * INFORMÁTICA: Fone Simples (R$ 25,00) | Headset Gamer (R$ 89,00) | Caixa de Som USB (R$ 45,00) | Carregador Universal (R$ 30,00) | Cabo USB-C (R$ 15,00) | Mouse Gamer (R$ 45,00) | Pen Drive 32GB (R$ 35,00)
  * CONVENIÊNCIA: Água Mineral (R$ 3,00) | Refrigerante Lata (R$ 5,00) | Salgadinho (R$ 4,00) | Chocolate (R$ 3,50)
- Área do Carrinho de Compras (Painel Lateral Integrado):
  * Tabela real/dinâmica mostrando colunas: Produto, Qtd, Valor Unitário, Subtotal.
  * Controle de quantidade (+ / -) e botão de lixeira (remover) funcionais para cada item inserido.
  * Rodapé do Carrinho: Exibição destacada do [ VALOR TOTAL GERAL ].
  * Botões de comando inferiores: "[ FINALIZAR VENDA ]", "[ LIMPAR CARRINHO ]", "[ CANCELAR ]".
- Interação: Clicar em "FINALIZAR VENDA" leva para a TELA 4B.

TELA 4B – RESUMO DA VENDA E IDENTIFICAÇÃO
- Área Central: Lista fiel contendo exatamente os itens selecionados no passo anterior, as quantidades e o Total Geral calculado.
- Campo Adicional Obrigatório: Input grande para "NOME DO CLIENTE (OPCIONAL)" com ícone identificador de usuário.
- Seletor de Forma de Pagamento (Grupo de Botões de Rádio Grandes): [ DINHEIRO ], [ PIX ], [ CARTÃO DE DÉBITO ], [ CARTÃO DE CRÉDITO ].
- Botões da Base: "[ CONFIRMAR VENDA (Alt + 4) ]" e "[ VOLTAR ]".
- Interação: Clicar em Confirmar valida a escolha e direciona para a TELA 5B.

TELA 5B – CONFIRMAÇÃO DA VENDA E RECIBO
- Mensagem principal em caixa alta: "VENDA REGISTRADA COM SUCESSO".
- Dados simulados da transação: Número da Venda gerado automaticamente (Ex: #84920), Data, Hora, Forma de Pagamento escolhida e o Valor Total Geral.
- Botões de Fluxo: "[ INICIAR NOVA VENDA ]", "[ VOLTAR AO MENU PRINCIPAL ]".
- COMPONENTE DE DESTAQUE: Botão estilizado em linha tracejada "[ VISUALIZAR RECIBO (Ícone de Olho + Impressora) ]".
- Interação: Clicar em "Visualizar Recibo" abre um elemento de modal sobreposto na tela.

MODAL INTERATIVO: PRÉVIA DO RECIBO PARA IMPRESSÃO
- Visual: Estilo cupom/comprovante térmico de terminal comercial real (fonte monoespaçada, bordas serrilhadas/tracejadas no topo e na base).
- Conteúdo do Cupom:
  * Cabeçalho da loja: "LUMINA PDV - LAN HOUSE | CNPJ: 00.000.000/0001-00".
  * Metadados: Cupom Nº, Data, Hora.
  * Nome do Cliente: Exibe o nome digitado na Tela 4B (se deixado em branco, exibe "CLIENTE BALCÃO").
  * Linha divisória tracejada (-----------------------------------------).
  * Lista de Itens detalhada no padrão: "Qtd x Descrição | V. Unit | Subtotal".
  * Rodapé do Cupom: Total de Itens, TOTAL GERAL DA VENDA e a Forma de Pagamento em letras garrafais.
- Ações do Modal: Botão de fechar "[ X FECHAR (Esc) ]" e botão em destaque "[ IMPRIMIR RECIBO ]" (que simula o comando de impressão limpo, ocultando fundos de tela).

Gere o fluxo completo dessas telas conectadas de forma lógica e horizontal, garantindo que o comportamento minimalista e todos os recursos de acessibilidade clicáveis estejam perfeitamente dispostos para a execução do protótipo de alta fidelidade.