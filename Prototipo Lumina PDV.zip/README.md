
  # Prototipo Lumina PDV

  This is a code bundle for Prototipo Lumina PDV. The original project is available at https://www.figma.com/design/v3QpsLKYlDexUQkI2HrFIj/Prototipo-Lumina-PDV.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  